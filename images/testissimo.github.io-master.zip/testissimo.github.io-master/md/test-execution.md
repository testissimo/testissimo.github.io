## Test execution

You can run any test by clicking on the play button in the right corner of the test. In development phase of some test you can also run single step of the test by clicking on the item “Run only this step” from the context menu

![](/cmsimages/ry_SV2blM.png)  



In development phase, you it is also convenient to run methods of component even without using them in test. You can to this using the “Run” menu item from the context menu of the chose component method. 
