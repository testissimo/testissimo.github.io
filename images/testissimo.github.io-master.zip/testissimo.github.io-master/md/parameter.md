## Parameter

In the examples above we have seen cases where we need to parametrize some CSS selectors or we want that the caller defines the parameter value of some other action parameter. We can use parameter for this purpose. Parameters are parsed automatically from actions and CSS selectors using the {parameter name} syntax.  
In the example below we can see parametrized CSS selector and parametrized method call setValue.

![](/cmsimages/SJksW3Zxz.png)  

  



When using this method, we can provide parameter values which will be used during the test execution

  

![](/cmsimages/ryahW2blM.png)
