## Macro

Sometimes we need to define reusable piece of execution which spans more than one component which means that it is not convenient to implement it as method of some component. For this purpose, we can create macro which is simple a set of  
component method execution or simple action which can be reused. As any other method, macros can be parametrized.

