## Test

Test is our final construct where we put the logic of single test. Technically tests and macros are equal so they have the same properties. Test can be organized in executable groups called Test suites which can be executed with a single click.  
